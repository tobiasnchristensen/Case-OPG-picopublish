import { Fragment } from "react"

function App() {


  
  return (
    <Fragment>
      <div className="rectangle1"></div>
      <p className="sloganBottom">Dine forhandler ressourcer for DYLAN puslepude</p>
      <div className="sloganbarTop"></div>
        <div className="sloganTop">BABYBOO FOR PROFESSIONALS</div>
      <nav className="navbarTop"></nav>
        <input type="search" className="searchbar"/>
      <div className="navbarFrame1"></div>
        <div className="navbarFrame2"></div>
         <div className="navbarBabyboo">BABYBOO</div>
         <div className="navbarFrame3"></div>
           <div className="navbarFrame4"></div>
            <p className="serierButton button-sibling">SERIER</p>
            <p className="vuggeButton button-sibling">VUGGE</p>
            <p className="børnesengeButton button-sibling">BØRNESENGE</p>
            <p className="opbevaringButton button-sibling">OPBEVARING</p>
            <p className="højstolButton button-sibling">HØJSTOL</p>
            <p className="pusleButton button-sibling">PUSLE</p>
            <p className="tekstilerButton button-sibling">TEKSTILER</p>
            <p className="tilbehørButton button-sibling">TILBEHØR</p>
            <p className="reservedeleButton button-sibling">RESERVEDELE</p>

    <div className="welcomeHeader">VELKOMMEN BABYBOB A/S</div>
    <div className="bestillingsliste">BESTILLINGSLISTE</div>

  </Fragment>

  );
}

export default App
